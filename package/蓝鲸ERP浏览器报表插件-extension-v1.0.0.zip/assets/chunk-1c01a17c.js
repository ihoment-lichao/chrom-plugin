console.info("chrome-ext template-vue-js content script");
